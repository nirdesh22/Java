
public class HiAdaLovelace {

    public static void main(String[] args) {
        String name = " Ada Lovelace";

        System.out.println("Hi" +name+"!");


    }
}
